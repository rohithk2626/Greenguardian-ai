import React, { useState, useRef, useEffect } from "react";
import { MessageSquare, Send, X, Leaf, Sparkles } from "lucide-react";
import { ChatMessage } from "../types";

export const Chatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [loading, setLoading] = useState(false);
  const [glow, setGlow] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const defaultPrompts = [
    "🍅 Prevent Tomato Blight",
    "🌿 Organic Fertilizers",
    "🐜 Get rid of Aphids",
    "🍋 Citrus Leaf Spots",
  ];

  // Initialize with a welcome message
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        {
          id: "welcome",
          role: "model",
          text: "Hello botanist! 🌿 I am your Green Guardian AI Assistant. Ask me anything about crop diseases, leaf-spots, companion planting, or natural pest control recipes!",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    }
  }, [messages]);

  // Scroll to bottom on updates
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: Math.random().toString(),
      role: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue("");
    setLoading(true);

    try {
      // Create history array
      const history = [...messages, userMsg].map((m) => ({
        role: m.role,
        text: m.text,
      }));

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: history }),
      });

      const data = await res.json();

      setMessages((prev) => [
        ...prev,
        {
          id: Math.random().toString(),
          role: "model",
          text: data.text || "I apologize, but I encountered an issue parsing that query.",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: Math.random().toString(),
          role: "model",
          text: "My connection to the garden database failed. Please verify that your backend server is online and try again. 🌐",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const toggleChat = () => {
    setIsOpen(!isOpen);
    setGlow(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-[999] font-sans antialiased">
      {/* Floating Button */}
      {!isOpen && (
        <button
          onClick={toggleChat}
          className={`flex items-center justify-center w-14 h-14 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white shadow-lg cursor-pointer transition-transform hover:scale-105 duration-200 relative ${
            glow ? "animate-pulse ring-4 ring-emerald-500/30" : ""
          }`}
          title="Ask Green Guardian AI"
        >
          <MessageSquare className="w-6 h-6" />
          <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-500 rounded-full flex items-center justify-center text-[8px] font-bold text-white border-2 border-white">
            1
          </span>
        </button>
      )}

      {/* Chat Windows Container */}
      {isOpen && (
        <div className="flex flex-col w-80 sm:w-96 h-[500px] bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl shadow-2xl overflow-hidden transition-all duration-300">
          {/* Header */}
          <div className="bg-emerald-800 text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-950 flex items-center justify-center">
                <Leaf className="w-4 h-4 text-emerald-300" />
              </div>
              <div>
                <h3 className="font-semibold text-sm leading-none flex items-center gap-1">
                  Green Guardian AI <Sparkles className="w-3 nav-logo h-3 text-amber-300" />
                </h3>
                <p className="text-[10px] text-emerald-200 mt-0.5">Online • Botanical Expert</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-emerald-100 hover:text-white p-1 hover:bg-emerald-700/60 rounded-lg cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-stone-50 dark:bg-stone-950">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col max-w-[80%] ${
                  msg.role === "user" ? "ml-auto items-end" : "mr-auto items-start"
                }`}
              >
                <div
                  className={`p-3 rounded-2xl text-xs whitespace-pre-line leading-relaxed shadow-sm ${
                    msg.role === "user"
                      ? "bg-emerald-700 text-white rounded-tr-none"
                      : "bg-white dark:bg-stone-900 text-stone-800 dark:text-stone-200 rounded-tl-none border border-stone-200 dark:border-stone-800"
                  }`}
                >
                  {msg.text}
                </div>
                <span className="text-[10px] text-stone-400 mt-1 px-1">{msg.timestamp}</span>
              </div>
            ))}

            {/* AI Loading state */}
            {loading && (
              <div className="flex flex-col max-w-[80%] mr-auto items-start">
                <div className="p-3 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-tl-none flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-emerald-700 rounded-full animate-bounce delay-100"></span>
                  <span className="w-1.5 h-1.5 bg-emerald-700 rounded-full animate-bounce delay-200"></span>
                  <span className="w-1.5 h-1.5 bg-emerald-700 rounded-full animate-bounce delay-300"></span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Prompts */}
          {messages.length <= 1 && (
            <div className="bg-stone-100 dark:bg-stone-950 px-4 py-2 flex gap-2 flex-wrap border-t border-stone-200 dark:border-stone-800">
              {defaultPrompts.map((prompt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(prompt.slice(2))}
                  className="text-[11px] bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-full px-2.5 py-1 text-stone-600 dark:text-stone-300 hover:border-emerald-500 hover:text-emerald-700 dark:hover:text-emerald-300 cursor-pointer"
                >
                  {prompt}
                </button>
              ))}
            </div>
          )}

          {/* Form Input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage(inputValue);
            }}
            className="p-3 bg-white dark:bg-stone-900 border-t border-stone-200 dark:border-stone-800 flex items-center gap-2"
          >
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask about blight, organic care, watering..."
              className="flex-1 text-xs px-3 py-2 bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-xl outline-none focus:border-emerald-600 focus:bg-white dark:focus:bg-stone-900 dark:text-white"
            />
            <button
              type="submit"
              disabled={!inputValue.trim() || loading}
              className="p-2 bg-emerald-700 disabled:bg-stone-300 text-white rounded-xl hover:bg-emerald-800 transition-colors disabled:cursor-not-allowed cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
