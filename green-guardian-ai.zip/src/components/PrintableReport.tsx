import React from "react";
import { AnalysisResult } from "../types";

interface PrintableReportProps {
  result: AnalysisResult;
  onClose: () => void;
}

export const PrintableReport: React.FC<PrintableReportProps> = ({ result, onClose }) => {
  React.useEffect(() => {
    // Automatically trigger print dialog when mounted
    const timer = setTimeout(() => {
      window.print();
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="fixed inset-0 bg-stone-100 dark:bg-stone-950/20 text-stone-900 print:bg-white z-[9999] p-4 sm:p-10 overflow-y-auto print-report font-sans">
      {/* Control Bar (hidden during printing) */}
      <div className="max-w-3xl mx-auto mb-6 flex flex-col sm:flex-row gap-4 justify-between items-center print:hidden bg-white border border-stone-200 rounded-xl p-4 shadow-md">
        <div className="text-center sm:text-left">
          <h2 className="text-sm font-semibold text-stone-800">Inspection Report Print Preview</h2>
          <p className="text-[11px] text-stone-400 mt-0.5">Use the print dialog window to print or save a PDF of this diagnostic sheet.</p>
        </div>
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            id="print_again_btn"
            onClick={() => window.print()}
            className="px-3.5 py-2 text-xs font-semibold text-stone-700 bg-stone-50 hover:bg-stone-100 border border-stone-300 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            🖨️ Re-open Print Dialog
          </button>
          <button
            id="return_site_btn"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            ← Return to Website
          </button>
        </div>
      </div>

      <div className="max-w-3xl mx-auto bg-white border border-stone-200 p-8 shadow-sm print:shadow-none print:border-none print:p-0">
        {/* Header */}
        <div className="border-b-2 border-emerald-800 pb-4 mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-serif text-emerald-800 font-bold mb-1">
              Green Guardian AI
            </h1>
            <p className="text-sm text-stone-500">
              Plant Disease Health Inspection & Diagnosis Report
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm font-semibold text-emerald-800">Date: {new Date().toLocaleDateString()}</p>
            <p className="text-xs text-stone-400">ID: {Math.random().toString(36).substring(2, 9).toUpperCase()}</p>
          </div>
        </div>

        {/* Diagnosis overview */}
        <div className="mb-6 bg-emerald-50 p-4 rounded-lg border border-emerald-200">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 block mb-1">
            Primary Diagnosis
          </span>
          <h2 className="text-2xl font-serif text-stone-900 font-medium mb-1">
            {result.disease}
          </h2>
          <p className="text-sm italic text-stone-600 mb-2">{result.scientific}</p>
          <div className="flex gap-4 text-xs mt-2">
            <span className="bg-emerald-100 text-emerald-800 px-3 py-1 rounded font-medium">
              Severity: {result.severity}
            </span>
            <span className="bg-emerald-100 text-emerald-800 px-3 py-1 rounded font-medium">
              Confidence Score: {result.confidence}%
            </span>
            <span className="bg-emerald-100 text-emerald-800 px-3 py-1 rounded font-medium">
              Spreading Risk: {result.spread_risk}%
            </span>
          </div>
        </div>

        {/* Symptoms */}
        <div className="mb-6">
          <h3 className="text-lg font-serif text-emerald-800 border-b border-stone-200 pb-1 mb-2 font-medium">
            Observable Symptoms Detected
          </h3>
          <ul className="list-disc pl-5 text-sm space-y-1.5 text-stone-700">
            {result.symptoms.map((symptom, idx) => (
              <li key={idx}>{symptom}</li>
            ))}
          </ul>
        </div>

        {/* Treatment Actions */}
        <div className="mb-6">
          <h3 className="text-lg font-serif text-emerald-800 border-b border-stone-200 pb-1 mb-3 font-medium">
            Recommended Treatment & Interventions
          </h3>
          
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-bold text-stone-800 uppercase tracking-wide">
                Immediate Action Steps
              </h4>
              <ul className="list-decimal pl-5 text-sm mt-1 text-stone-600 space-y-1">
                {result.treatment.immediate.map((step, idx) => (
                  <li key={idx}>{step}</li>
                ))}
              </ul>
            </div>

            <div className="grid grid-cols-2 gap-4 mt-2">
              <div>
                <h4 className="text-sm font-bold text-stone-800 uppercase tracking-wide">
                  Organic Controls
                </h4>
                <ul className="list-disc pl-5 text-xs mt-1 text-stone-600 space-y-1">
                  {result.treatment.organic.map((step, idx) => (
                    <li key={idx}>{step}</li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="text-sm font-bold text-stone-800 uppercase tracking-wide">
                  Chemical Treatments
                </h4>
                <ul className="list-disc pl-5 text-xs mt-1 text-stone-600 space-y-1">
                  {result.treatment.chemical.map((step, idx) => (
                    <li key={idx}>{step}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="mt-2">
              <h4 className="text-sm font-bold text-stone-800 uppercase tracking-wide">
                Long-Term Prevention & Garden Hygiene
              </h4>
              <ul className="list-disc pl-5 text-sm mt-1 text-stone-600 space-y-1">
                {result.treatment.prevention.map((step, idx) => (
                  <li key={idx}>{step}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-stone-200 pt-4 mt-8 text-center text-xs text-stone-400">
          <p>This document is generated by Green Guardian AI for plant care and academic purposes.</p>
          <p>© 2026 Green Guardian AI. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
};
